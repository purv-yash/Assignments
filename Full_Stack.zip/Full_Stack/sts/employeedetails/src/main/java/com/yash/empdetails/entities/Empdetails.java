package com.yash.empdetails.entities;

public class Empdetails {

	private String empname;
	private int empid;
	private String dob;
	private double contactno;
	private int salary;
	@Override
	public String toString() {
		return "Employee [empname=" + empname + ", empid=" + empid + ", dob=" + dob + ", contactno=" + contactno
				+ ", salary=" + salary + "]";
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public double getContactno() {
		return contactno;
	}
	public void setContactno(double contactno) {
		this.contactno = contactno;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public Empdetails(String empname, int empid, String dob, double contactno, int salary) {
		super();
		this.empname = empname;
		this.empid = empid;
		this.dob = dob;
		this.contactno = contactno;
		this.salary = salary;
	}
	public Empdetails() {
		super();
	
	}
	
	
	
	
}
