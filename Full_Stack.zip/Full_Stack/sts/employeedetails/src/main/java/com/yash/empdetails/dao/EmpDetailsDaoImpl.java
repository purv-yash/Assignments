package com.yash.empdetails.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import com.yash.empdetails.entities.Empdetails;
import com.yash.springjdbc.entities.Student;

public class EmpDetailsDaoImpl implements EmpDetailsDao {
	
	private JdbcTemplate jdbctemp;

	@Override
	public int insert(Empdetails emp) {
		//insert details of employee
		String q="insert into empdetails(empname,empid,dob,contactno,salary) values(?,?,?,?,?)";
		int msg=this.jdbctemp.update(q,emp.getEmpname(),emp.getEmpid(),emp.getDob(),emp.getContactno(),emp.getSalary());
		return msg;
	}
	
	public int updatedetails(Empdetails emp) {
		// update details of employee
		String q="update student set name=? where id=?";
		int msg=this.jdbctemp.update(q,emp.getEmpname(),emp.getEmpid());
		return msg;
	}
	
	public int delete(Empdetails emp) {
		// delete details of employee
		String q="delete from student where id=?";
		int msg=this.jdbctemp.update(q,emp.getEmpid());
		return msg;

	}
	
		public JdbcTemplate getJdbctemp() {
		return jdbctemp;
		}
		public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
		}
	

}
