package com.yash.empdetails.dao;

import com.yash.empdetails.entities.Empdetails;

public interface EmpDetailsDao {
	
	public int insert(Empdetails emp);
	public int update(Empdetails emp);
	public int delete(Empdetails emp);

}
