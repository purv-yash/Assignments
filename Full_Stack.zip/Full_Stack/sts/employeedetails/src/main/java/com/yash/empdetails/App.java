package com.yash.empdetails;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.empdetails.dao.EmpDetailsDao;
import com.yash.empdetails.entities.Empdetails;


public class App {

	public static void main(String[] args) {
		System.out.println( "Hello World!" );
		ApplicationContext context=new ClassPathXmlApplicationContext("com/yash/empdetails/ac.xml");
		EmpDetailsDao stdao=context.getBean("EmpDetailsDao",EmpDetailsDao.class);
		
		Empdetails e= new Empdetails();
		e.setEmpname("purv");
		e.setEmpid(1001);
		e.setDob("2022-06-01");
		e.setContactno(987654230);
		e.setSalary(10602);
		
		int r=stdao.insert(e);
		System.out.println(r + "Employee updated Successfully ");
	}

}
