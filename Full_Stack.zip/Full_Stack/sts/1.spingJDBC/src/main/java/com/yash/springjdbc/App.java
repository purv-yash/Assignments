package com.yash.springjdbc;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.springjdbc.dao.StudentDao;
import com.yash.springjdbc.entities.Student;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println( "Hello World!" );
		ApplicationContext context=new ClassPathXmlApplicationContext("com/yash/springjdbc/applicationcontext.xml");
		StudentDao stdao=context.getBean("StudentDao",StudentDao.class);

//		Student s=new Student();
//		s.setName("hariom");
//		s.setId(101);
//		s.setId(108);
//		s.setName("jaynam");
//		int r=stdao.insert(s);
//		int r=stdao.updatedetails(s);
//		System.out.println(r + "Student updated Successfully ");
//
//		Student s=stdao.selectDetails(101);
//		System.out.println(s);

		List<Student> stu=stdao.getAllDetails();
		for(Student s:stu)
		{
		System.out.println(s);
		}
	}

}
