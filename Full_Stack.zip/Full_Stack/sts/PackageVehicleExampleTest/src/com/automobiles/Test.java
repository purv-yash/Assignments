package com.automobiles;
import com.automobiles.twoWheeler.*;
public class Test
{
	public static void main(String[] args)
	{
		Honda h = new Honda();
		System.out.println(h.getSpeed());
	}
}