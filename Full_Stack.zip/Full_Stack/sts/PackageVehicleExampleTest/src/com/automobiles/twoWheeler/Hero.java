package com.automobiles.twoWheeler;
import com.automobiles.Vehicle;

public class Hero extends Vehicle
{
	public int getSpeed(){ return 100;}
	public void radio(){System.out.println("Radio");}
	public String getModelName() { return "HERO";}
	public String getRegistrationNumber() { return "453";}
	public String getOwnerName() { return "PURV";}
}