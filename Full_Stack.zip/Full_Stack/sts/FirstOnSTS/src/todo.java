import java.util.*;
import java.io.*;
public class todo {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int x= sc.nextInt();
		int y= sc.nextInt();
		int z;
		try {
			z=x/y;
			System.out.println(z);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
