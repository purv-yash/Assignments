package com.restapi.Hibernate1Demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.internal.MetadataBuilderImpl;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class EmployeeDao {
	
	public static SessionFactory sfct = null;
	public static SessionFactory Data()
	{
		StandardServiceRegistry srt  = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		Metadata meta = new MetadataSources(srt).getMetadataBuilder().build();
		sfct = meta.getSessionFactoryBuilder().build(); 
		return sfct;
	}
	
	
	
	public static void main(String[] args) {
		
		EmployeeDao.Data();
		System.out.println(sfct);
		Session s = sfct.openSession();
		Transaction t = s.beginTransaction();
		
		Employee e1 = new Employee();
		e1.setName("abc");
		e1.setSalary("91000001");

		s.save(e1);
		t.commit();
		
		s.close();
		
	
	}
}
