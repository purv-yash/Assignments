package com.map.MappingOneTwoOneDemo2;


import javax.persistence.*;

@Entity
@Table(name="Tab2")
public class Tab2 {

	
		@Id	
		@Column(name="id")
		private int id;
		
		@Column(name="city")
		private String city;

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getCity() {
			return city;
		}

		public void setCity(String city) {
			this.city = city;
		}
		public Tab2(int id, String city) {
			super();
			this.id = id;
			this.city = city;
		}
		public Tab2() {
			super();
			
		}
		
}
