package com.map.MappingOneTwoOneDemo2;


import javax.persistence.*;


@Entity
@Table (name="Tab1")
public class Tab1 {
	

	


		@Id
		@Column(name="id")
		private int id;
		
		@Column(name="name")
		private String name;
		
		@OneToOne(targetEntity = Tab2.class)
		@JoinColumn(name="a_id")
		private Tab2 a_id;
		
		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public Tab2 getA_id() {
			return a_id;
		}

		public void setA_id(Tab2 a_id) {
			this.a_id = a_id;
		}

		public Tab1(int id, String name, Tab2 a_id) {
			super();
			this.id = id;
			this.name = name;
			this.a_id = a_id;
		}
		public Tab1() {
			super();
			
		}


}
