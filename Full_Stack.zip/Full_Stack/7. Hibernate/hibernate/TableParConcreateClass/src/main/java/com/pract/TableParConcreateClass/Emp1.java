package com.pract.TableParConcreateClass;

import javax.persistence.*;

@Entity
@Table(name="Emp1")
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class Emp1 {
	

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="id")
	private int id;

	@Column(name="name")
	private String name;
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	public Emp1(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public Emp1() {
	
	}
	
	

}
