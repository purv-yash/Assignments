package com.pract.TableParConcreateClass;

import javax.persistence.*;

@Entity
@Table(name="Temp_Emp")
@AttributeOverrides(
		{
			@AttributeOverride(name="id",column=@Column(name="id")),
			@AttributeOverride(name="name",column = @Column(name="name"))
		})
public class Temp_Emp extends Emp1{
	
	public Temp_Emp(int pay_pr_hour, int work_hour) {
		super();
		this.pay_pr_hour = pay_pr_hour;
		this.work_hour = work_hour;
	}
	public Temp_Emp() {

	}

	@Column(name="pay_pr_hour")
	private int pay_pr_hour;

	@Column(name="work_hour")
	private int work_hour;
	
	
	public int getPay_pr_hour() {
		return pay_pr_hour;
	}

	public void setPay_pr_hour(int pay_pr_hour) {
		this.pay_pr_hour = pay_pr_hour;
	}

	public int getWork_hour() {
		return work_hour;
	}

	public void setWork_hour(int work_hour) {
		this.work_hour = work_hour;
	}

	
	
}
