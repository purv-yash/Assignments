class A
{
	void display()
	{
		System.out.println("In A class");
	}
}

class SuperDemo2 extends A
{
	void display()
	{
		System.out.println("In SuperDemo2 class");
	}
	void show()
	{
		display();
		super.display();
	}
	public static void main(String[] args)
	{
		SuperDemo2 sd = new SuperDemo2();
		sd.show();
	}
}