class Array12d
{
	public static void main(String[] args)
	{
			int[][] a=new int[][]{{10,20},{30,40}};
			
			int sum=0, avg;
			for(int i[]:a)
			{
				for(int j:i)
				{
				sum= sum+j;
				}
			}
			int x= a[0].length+a[1].length;
			avg= sum/x ;
	System.out.println("sum is:"+ sum);
	System.out.println("avg is:"+ avg);
	}
}