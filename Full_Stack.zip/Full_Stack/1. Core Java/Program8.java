import java.util.*;
class Program8{
public static void main(String[] args){
 Scanner sc= new Scanner(System.in);
 System.out.println("a=");
 int a= sc.nextInt();
 
	for(int n=1;n<=10;n++)
	{
	System.out.println(a +"*"+ n + "=" + a*n);	
	}
}
}