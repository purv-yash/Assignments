import java.util.*;
class Program4{
public static void main(String[] args){
 Scanner sc= new Scanner(System.in);
 int a= sc.nextInt();
 
 if(a%4 == 0) System.out.println(a + "is a leap year" );
 else System.out.println(a +"is not a leap year");
}
}