import java.util.ArrayList;

public class ArrayList1 {

	public static void main(String[] args) {

		ArrayList a = new ArrayList();
		a.add(10);
		a.add("Purv");
		a.add('b');
		a.add("Baraskar");
		a.add(22);
		System.out.println(a);
//		for(int e: ArrayList)
//		{
//			System.out.println(e);
//		}
	}

}
