import java.util.Vector;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Collection;

class ListAssignment3{
	public static void main(String[] args){
Vector<String> v = new Vector<>();
		v.add("Jan");
		v.add("Feb");
		v.add("Mar");
		v.add("April");
		v.add("May");
		v.add("June");
		v.add("July");
		v.add("Aug");
		v.add("Sep");
		v.add("Oct");
		v.add("Nov");
		v.add("Dec");
		Iterator<String> itr = v.iterator();
		while(itr.hasNext()){
			System.out.print(itr.next() + " ");
		}
		
		v.remove("Jan");
		
		System.out.println(v);
		 Collection<String> c = new ArrayList<String>();
        c.add("Jan");
        c.add("Feb");
        c.add("Mar");
        c.add("Apr");
        c.add("May");
  
       System.out.println("The Vector is: " + v);
  
        v.addAll(c);
		System.out.println("The new vector is: " + v);
	}
}