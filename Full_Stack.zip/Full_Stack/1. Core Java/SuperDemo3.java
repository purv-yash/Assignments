class A
{
	A()
	{
		System.out.println("In A class");
	}
}

class SuperDemo3 extends A
{
	SuperDemo3()
	{
		System.out.println("In SuperDemo2 class");
	}
	
	public static void main(String[] args)
	{
		SuperDemo3 sd = new SuperDemo3();
		
	}
}