class Constructor
{
	String name;
	int age;

	Constructor()
	{
		System.out.println("Default Constructor");
	}
	
	Constructor(String name, int age)
	{
		this.name = name;
		this.age  = age;
	}
	public static void main(String[] args)
	{
		Constructor dog = new Constructor();
		Constructor cat = new Constructor("Tom",2);
		
		System.out.println(cat.name);
	}

}