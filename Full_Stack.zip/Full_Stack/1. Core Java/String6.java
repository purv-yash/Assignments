class String6
{
	public static void main(String[] args)
	{
		String s = new String("Purv Baraskar");
		String s1 = new String("Purv");
	
		
		System.out.println(s.compareToIgnoreCase(s1));
		
	}
}