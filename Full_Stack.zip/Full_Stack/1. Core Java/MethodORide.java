class Parent
{
	Object run()
	{
		System.out.println("parent are running");
		return 0;
	}
}
class Child extends Parent
{
	String run()
	{
		System.out.println("Child is running");
		return 0;
	}
	public static void main(String[] args)
	{
		Parent p1 = new Parent();
		Child c1 = new Child();
		c1.run();
		p1.run();
	}
}