class Array2
{
	public static void main(String[] args)
	{
			int[] a=new int[]{10,20,80,40,5,60};
			int max=0,min= a[0];
			for(int i:a)
			{
				if(i>max) max= i;
				if(i<min) min= i;
			}
	System.out.println("smallest no. is:"+ max);
	System.out.println("biggest no. is:"+ min);
	}
}