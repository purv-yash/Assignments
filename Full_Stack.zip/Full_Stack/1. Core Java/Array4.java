class Array4
{
	public static void main(String[] args)
	{
			int[] a=new int[]{10,20,80,40,5,60};
			int l1=a[0],l2=a[1],temp= 0;
			if(l1<l2)
			{
				temp= l1;
				l1=l2;
				l2=temp;
			}
			for(int i:a)
			{
				if(i>l1) {l2= l1; l1= i;}
				else if(i>l2 && i!= l1) l2=i;
			}
	System.out.println("largest no. is:"+ l1);
	System.out.println("second largest no. is:"+ l2);
	}
}