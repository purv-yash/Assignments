
public class FirstClassSTS {
public static void main(String[] args) {
	System.out.print("My first program on STS.");
}
}
