import java.util.Scanner;
class ExceptionAssignment2
{
	public static void main(String[] args)
	{
		try
		{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no. of elements in the array");
		int x= sc.nextInt();
		int[] a= new int[x];
		System.out.println("Enter elements in the array");
		for(int i=0; i<a.length; i++)
		{
			a[i]= sc.nextInt();
		}
		System.out.println("Enter the index of array element you want to access");
		int c= sc.nextInt();
		System.out.println("the array element at index"+c+"is" + a[c]);		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}