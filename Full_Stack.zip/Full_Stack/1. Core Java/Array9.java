class Array9
{
	public static void main(String[] args)
	{
			int[][] a=new int[2][2];
			a[0][0]= Integer.parseInt(args[0]);
			a[0][1]= Integer.parseInt(args[1]);
			a[1][0]= Integer.parseInt(args[2]);
			a[1][1]= Integer.parseInt(args[3]);
			
			System.out.println("Given array is:");
			for(int i[]:a)
			{
				for(int j:i)
				{
				System.out.print(j +" ");
				}
				System.out.println();
			}
			System.out.println("Reversed array is:");
			for(int x=1; x>=0; x--)
			{
				for(int y=1; y>=0; y--)
				{
				System.out.print(a[x][y]+ " ");
				}
				System.out.println();
			}
	}
}