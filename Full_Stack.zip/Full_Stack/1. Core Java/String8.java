import java.util.Scanner;

class String8
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		
		String s = sc.nextLine();
		int x = 0, i=0;
		int j= s.length();
		
		while(i==j)
		
		
		if(x==0)
		System.out.println("it is palindrome name");
		
		else System.out.println("it is not palindrome name");
	}
}