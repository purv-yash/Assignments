import java.util.LinkedList;

class LinkedListDemo1
{
	public static void main(String[] args)
	{
		LinkedList ll= new LinkedList();
		ll.add("Purv");
		ll.add(2);
		ll.add("Baraskar");
		System.out.println(ll);
		
		LinkedList<String> ll1= new LinkedList<String>();
		ll1.add("Purv");
		ll1.add("to");
		ll1.add("Baraskar");
		System.out.println(ll1);
		
		
	}
}