class Array3
{
	public static void main(String[] args)
	{
			int[] a=new int[]{10,20,30,40,50,60};
			int z=0,y=0,x= 15	;
			
			for(int i:a)
			{
				y++;
				if(i==x)
				{
					System.out.println(y);
					z++;
				}
			}
			if(z==0)System.out.println("-1");
	}
}