class Array10
{
	public static void main(String[] args)
	{
			int[][] a=new int[3][3];
			a[0][0]= Integer.parseInt(args[0]);
			a[0][1]= Integer.parseInt(args[1]);
			a[0][2]= Integer.parseInt(args[2]);
			a[1][0]= Integer.parseInt(args[3]);
			a[1][1]= Integer.parseInt(args[4]);
			a[1][2]= Integer.parseInt(args[5]);
			a[2][0]= Integer.parseInt(args[6]);
			a[2][1]= Integer.parseInt(args[7]);
			a[2][2]= Integer.parseInt(args[8]);
			int max= 0;
			System.out.println("the given array is:");
			for(int i[]:a)
			{
				for(int j:i)
				{
				System.out.print(j+ " ");
				
				}
				System.out.println();
			}
			for(int i[]:a)
			{
				for(int j:i)
				{
				if(j> max)
								max= j;
				
				}
			}
			System.out.println(max);
	}
}