import java.util.Scanner;
class AON extends RunTimeException
{
	AON(String s)
	{
		super(s);
	}
}
class ThrowAssignment6
{
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("enter marks of student 1:");
		int a1 =sc.nextInt();
		int a2 =sc.nextInt();
		int a3 =sc.nextInt();
		System.out.println("enter marks of student 2:");
		int b1 =sc.nextInt();
		int b2 =sc.nextInt();
		int b3 =sc.nextInt();
		
	}
} 