interface LibraryUser 
{
	public abstract void registerAccount();
	public abstract void requestBook();
}

class KidUsers implements LibraryUser
{
	int age;
	String bookType;
	public void registerAccount()
	{
		if (age<12) System.out.println("You have successfully registered under a Kids Account");
		else System.out.println("Sorry, Age must be less than 12 to register as a kid");
	}
	public void requestBook()
	{
		if (bookType == "kids") System.out.println("Book issued successfully, please return the bool within 10 days");
		else System.out.println("Oops, you are allowed to take only kids books");
	}
}
class AdultUsers implements LibraryUser
{
	int age;
	String bookType;
	public void registerAccount()
	{
		if (age>12) System.out.println("You have successfully registered under a Adult Account");
		else System.out.println("Sorry, Age must be greater than 12 to register as an adult");
	}
	public void requestBook()
	{
		if (bookType == "fiction") System.out.println("Book issued successfully, please return the bool within 7 days");
		else System.out.println("Oops, you are allowed to take only fiction books");
	}
}
class LibraryinterfaceDemo
{
	public static void main(String[] args)
	{
		KidUsers k = new KidUsers();
		AdultUsers a= new AdultUsers();
		k.age=10;
		a.bookType= "kids";
		k.registerAccount();
		a.requestBook();
	}
}