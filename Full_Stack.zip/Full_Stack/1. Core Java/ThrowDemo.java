import java.util.Scanner;
class VoteE extends RuntimeException
{
	VoteE (String s)
	{
		super(s);
	}
}
class ThrowDemo
{
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("age=");
		int age= sc.nextInt();
		try
		{
			if(age<18)
			{
				throw new VoteE("you're not eligible");
			}
			else System.out.println("you can vote");
		}
		catch(VoteE e)
		{
			e.printStackTrace();
		}
		System.out.println("normal termination");
	}
}