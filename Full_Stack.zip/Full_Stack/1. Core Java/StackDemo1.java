import java.util.Stack;

class StackDemo1
{
	public static void main(String[] args)
	{
		Stack s= new Stack();
		s.add("Purv");
		s.add(2);
		s.add("Baraskar");
		System.out.println(s);
	}
}