class Pattern1{
public static void main(String[] args){
 for(int n=1;n<=5;n++){
 for(int m=1;m<=5;m++){
 
		if(m <= n) System.out.print("*");
  }
  System.out.println();
 }
}
}