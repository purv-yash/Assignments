import java.io.*;
import java.util.Scanner;
class Employee implements Serializable
{
	String name, department,designation;
	double salary;
	
	Employee(String name, String department, String designation, double salary)
	{
		this.name=name;					
		this.designation=designation;
		this.department=department;		
		this.salary=salary;
	}
	
	public String toString()
	{
		return "[name=" + name + ",dapartment=" + department+ ", designation="+ designation + ",salary=" + salary + "]";
	}
	
	public static void main(String[] args) throws Exception
	{
		Employee emp = new Employee("purv", "IT", "MR", 40);
		
		File f = new File("d:/yash.txt");
		ObjectOutputStream oos= new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(e);
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
		
		e= (Employee)ois.readObject();
		System.out.println(e);
		oos.close();
		ois.close();
	}
}