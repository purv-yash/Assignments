import java.util.*;
class Program6{
public static void main(String[] args){
 Scanner sc= new Scanner(System.in);
 System.out.println("a=");
 int a= sc.nextInt();
 System.out.println("b=");
 int b= sc.nextInt();
 int c;
 
 c= a;
 a= b;
 b= c;
 System.out.println("a=" + a);
 System.out.println("b=" + b);
}
}