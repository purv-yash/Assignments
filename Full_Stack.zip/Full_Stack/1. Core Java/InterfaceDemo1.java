interface IET
{
	void location1();
}
interface SGSITS
{
	void location2();
}
class Demo implements IET,SGSITS
{
	public void location1()
	{
		System.out.println("IET located near IT Park");
	}
	public void location2()
	{
		System.out.println("SGSITS located near Railway Station");
	}
	public static void main(String[] args)
	{
			Demo d = new Demo();
			d.location1();
			d.location2();
	}
}