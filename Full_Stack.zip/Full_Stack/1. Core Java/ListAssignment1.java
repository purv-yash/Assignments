import java.util.ArrayList;
import java.util.Iterator;

class ListAssignment1 {

	public static void main(String[] args) {

		ArrayList<String> a = new ArrayList<String>();
		a.add("january");
		a.add("february");
		a.add("march");
		a.add("april");
		a.add("may");
		a.add("june");
		a.add("july");
		a.add("august");
		a.add("september");
		a.add("october");
		a.add("november");
		a.add("december");
		
		//1
		System.out.println(a);
		
		//2
		for(String x:a)
		{
			System.out.println(x);
			
		}
		
		//3
		Iterator i= a.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		
	}

}
