class Box
{
	int w,h,d,vol;
	Box(int w,int h,int d)
	{
		this.w=w;
		this.h=h;
		this.d=d;
	}
	void volume()
	{
		vol=w*h*d;
		System.out.println(vol);
	}
	
	public static void main(String[] args)
	{
		Box b1 = new Box(10,20,30);
		Box b2 = new Box(22,44,50);
		b1.volume();
		b2.volume();
	}
}