class Animal
{
	public static void main(String[] args)
	{

	}

}