class String3
{
	public static void main(String[] args)
	{
		String s = new String("Purv");
		String s1 = new String("Baraskar");
	
		
		System.out.println(s.equals(s1));
		
	}
}