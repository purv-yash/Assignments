import java.io.*;

public class FileAssignment1
{
	public static void main(String[] args) throws IOException
	{
		File f = new File("d:/yash.txt);
	}
}