package Project;
import java.util.Scanner;

public class HR
{
	public static void main(String[] args) throws Exception 
	{
		Scanner sc = new Scanner(System.in);
		Company c = new Company();
		loop: while(true)
		{
			System.out.println("\nChoose one option");
			System.out.println(" 1. Create employee");
			System.out.println(" 2. Get all employee");
			System.out.println(" 3. Get one employee");
			System.out.println(" 4. Update employee Salary");
			System.out.println(" 5. Remove one employee");
			System.out.println(" 6. Exit");
			

			System.out.print("Enter option: ");
			int option = sc.nextInt(); 
			
			switch(option) 
			{
			
			case 1: {//save employee 
					Employee emp = new Employee();
				
					System.out.print("  Enter eno\t\t: ");					
					emp.setEmpNo(sc.nextInt()); sc.nextLine();

					System.out.print("  Enter ename\t\t: ");					
					emp.setName(sc.nextLine());
					
					System.out.print("  Enter dept\t\t: ");					
					emp.setDept(sc.nextLine());
					
					System.out.print("  Enter sal\t\t: ");					
					emp.setSal(sc.nextDouble()); sc.nextLine();
									
					System.out.print("  Enter address\t\t: ");	
					emp.setAddress(sc.nextLine());
				
					c.addEmployee(emp);
					break;
					}
			
			case 2: { //get all employee
					c.getEmployee();
					break;
					}
			
			case 3: { //get all employees
					System.out.print("Enter Employee No: ");
					int empNo = sc.nextInt(); sc.nextLine();
					c.getEmployee(empNo);
					break;
					}		
			
			case 4: {//updating salary
					System.out.print("Enter Employee No: ");
					int empNo = sc.nextInt(); sc.nextLine();
					System.out.print("Enter Increment : ");
					int i= sc.nextInt(); sc.nextLine();
					c.updateSal(empNo, i);
					break;
					}
			
			case 5: {//remove one employee
					System.out.print("Enter Employee No: ");
					int empNo = sc.nextInt(); sc.nextLine();
					c.removeEmployee(empNo);
					break;
					}
			
			case 6: { //exit
					System.out.println("Thank You");
					break loop;
					}
			
			default:{
					System.out.println("Invalid option");
					}
			} 
		}		
	}
}

