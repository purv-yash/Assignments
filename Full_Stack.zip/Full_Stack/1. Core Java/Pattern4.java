class Pattern4{
public static void main(String[] args){
	int x=1;
 for(int n=1;n<=5;n++){
 for(int m=1;m<=5;m++){
 
		if(m <= n){ System.out.print(x +" ");
		x++;}
  }
  System.out.println();
 
 }
}
}