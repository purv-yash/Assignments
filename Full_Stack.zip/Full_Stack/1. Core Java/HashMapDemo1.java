import java.util.HashMap;

class HashMapDemo1
{
	public static void main(String[] args)
	{
		HashMap hm= new HashMap();
		hm.put(101,"Purv");
		hm.put(102,2);
		hm.put(103,"Baraskar");
		System.out.println(hm);
	}
}