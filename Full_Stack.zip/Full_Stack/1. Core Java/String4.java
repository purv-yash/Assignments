class String4 
{
	public static void main(String[] args)
	{
		String s = new String("Purv");
		String s1 = new String("purv");
	
		
		System.out.println(s.equalsIgnoreCase(s1));
		
	}
}