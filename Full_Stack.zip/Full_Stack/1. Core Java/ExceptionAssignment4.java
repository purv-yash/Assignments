class ExceptionAssignment4
{
	public static void main(String[] args)
	{
		int []a = new int[5];
		int sum=0;
		try
		{
			for (int i=0; i<a.length; i++)
			{
				a[i]=Integer.parseInt(args[i]);
				sum=sum+a[i];
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		System.out.println("sum is" + sum);
		System.out.println("sum is" + sum/a.length);
	}
}