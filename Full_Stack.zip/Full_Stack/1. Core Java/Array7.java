class Array7
{
	public static void main(String[] args)
	{
			int[] a=new int[]{10,20,30,40,50,31,60};
			
			
			for(int i=0;i<a.length;i++)
			{
				for(int j=0;j<a.length;j++)
				{
				if(a[j]== a[i]--)
				{
					a
				}
				}
			}	
	}
}