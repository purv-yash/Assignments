class Fruit
{
	String name, taste;
	int size;
	
	Fruit(String name, String taste, int size)
	{
		this.name= name;
		this.taste= taste;
		this.size= size;
	}
	void eat()
	{
		System.out.println(name + "is" + taste);
	}
}
class Apple extends Fruit
{
	Apple(String name, String taste, int size)
	{
		super(name,taste,size);
	}
	void eat()
	{
		System.out.println("Apple is sweet in taste");
	}
}
class Orange extends Fruit
{
	Orange(String name, String taste, int size)
	{
		super(name,taste,size);
	}
	void eat()
	{
		System.out.println("Orange is sour in taste");
	}
}
class Override1
{
	public static void main(String[] args)
	{
		Fruit f = new Fruit("Banana","Sweet",5);
		Apple a = new Apple("Apple","Sweet",8);
		Orange o = new Orange("Orange","Sour",8);
		
		f.eat();
		a.eat();
		o.eat();
	}
}