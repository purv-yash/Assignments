class Employee
{
	private int empid;
	public void setEmpId(int empid)
	{
		this.empid=empid;
	}
	public int getEmpId()
	{
		return empid;
	}
}
class Organization
{
	public static void main(String[] args)
	{
		Employee e= new Employee();
		e.setEmpId(1000);
		System.out.println(e.getEmpId());
	}
}
