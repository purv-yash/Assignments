class EnumSeason
{
	enum Season
	{
		SUMMER(1), SPRING(2), RAINY(3), WINTER(4);
		int n;
		Season (int n){this.n= n;}
	}
	public static void main(String[] args)
	{
		for(Season s: Season.values())
		{
			System.out.println(s +" "+  s.n);
		}
		System.out.println("index of Rainy season is:"+ Season.RAINY.ordinal());
	}
}