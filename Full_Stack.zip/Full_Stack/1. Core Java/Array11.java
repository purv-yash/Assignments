class Array11
{
	public static void main(String[] args)
	{
			int[] a=new int[]{10,20,30};
			int[] b=new int[]{40,50,60};
			
			int[] c=new int[2];
			c[0]=a[1]; c[1]=b[1];
			
			for(int i:c)
			{
				System.out.print(i + " ");
			}
	}
}