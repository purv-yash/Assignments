class Patient
{
	String patientName;
	double height, weight,BMI;
	
	Patient(double h,double w)
	{
		this.height= h;
		this.weight= w;
		
	}
	double computeBMI()
	{
		BMI= weight/(height*height);
		return BMI;
	}
	
	public static void main(String[] args)
	{
		Patient p1= new Patient(1.8,60);
		System.out.println(p1.computeBMI());
	}
}