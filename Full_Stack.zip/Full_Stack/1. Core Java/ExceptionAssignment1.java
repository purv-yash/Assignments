class ExceptionAssignment1
{
	public static void main(String[] args)
	{
		try
		{
		int a=Integer.parseInt(args[0]);
		int sq= a*a;
		System.out.println(sq);
		}
		catch(Exception e)
		{
			System.out.println("Entered input is not a valid format for an integer");
		}
	}
}