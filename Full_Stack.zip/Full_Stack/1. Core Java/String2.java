class String2
{
	public static void main(String[] args)
	{
		String s = new String("     Purv    ");
		//String s1 = new String();
	
		
		System.out.println(s.trim());
		
	}
}