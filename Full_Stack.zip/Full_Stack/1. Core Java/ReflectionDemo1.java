class ReflectionDemo1
{
	public static void main(String[] args) throws Exception
	{
	int[] a= new int[5];
	
	System.out.println(a.getClass().isArray());
	}
}