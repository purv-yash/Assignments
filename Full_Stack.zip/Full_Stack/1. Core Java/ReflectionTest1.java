import java.lang.reflect.*;
import java.lang.Class;

class Animal
{
}
class RTDog extends Animal
{
	public void display()
	{
		System.out.println("I'm a dog.");
	}
}
class RTMain
{
	public static void main(String[] args)
	{
		try
		{
			RTDog d1 = new RTDog();
			
			Class obj = d1.getClass();
			
			String name = obj.getName();
			System.out.println("Name:" + name);
			
			int modifier = obj.getModifiers();
			
			String mod = Modifier.toString(modifier);
			System.out.println("Modifier:"+ mod);
			
			Class superClass = obj.getSuperclass();
			System.out.println("Superclass:"+ superClass.getName());
		}

		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}