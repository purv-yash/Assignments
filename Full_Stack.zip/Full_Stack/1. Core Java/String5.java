class String5
{
	public static void main(String[] args)
	{
		String s = new String("Purv Baraskar");
		String s1 = new String("Purv ");
	
		
		System.out.println(s.compareTo(s1));
		
	}
}