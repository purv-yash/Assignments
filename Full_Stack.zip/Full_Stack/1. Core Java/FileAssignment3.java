import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class FileAssignment3
{
	public static void main(String[] args) throws IOException
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("file name");
		String f = sc.nextLine();
		System.out.println("characters to be counted");
		char c = sc.nextLine().charAt(0);
		File f1 = new File(f);
		int count = 0;
		BufferedReader br = new BufferedReader(new FileReader(f1));
		int ch;
		
		do
		{
			ch = br.read();
			if(ch >= 'A' && ch <= 'Z') ch++;
			if(c  >= 'A' && c  <= 'Z') ch++;
			if(ch == c)
				count++;
		}
		while (ch != -1);
		System.out.println(count);
		br.close();
	}
}