import java.util.*;
class Program9{
public static void main(String[] args){
 Scanner sc= new Scanner(System.in);
 System.out.println("a=");
 int a= sc.nextInt();
 int res=1;
	for(int n=1;n<=a;n++)
	{
	res= n* res;
	}
	
	System.out.println(res);
}
}