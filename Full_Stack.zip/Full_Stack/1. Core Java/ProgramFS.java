import java.util.*;
class ProgramFS{
public static void main(String[] args){
 Scanner sc= new Scanner(System.in);
 System.out.println("a=");
 int a=sc.nextInt();
 int m=0, n=1,b;
 System.out.println(m);
 System.out.println(n);
 
	for(int p=3;p<=a;p++)
	{
	b=m+n;
	System.out.println(b);
	m=n;
	n=b;
	}
	
}
}