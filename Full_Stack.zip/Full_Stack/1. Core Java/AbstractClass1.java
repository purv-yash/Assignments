abstract class GenralBank
{
	abstract void getSavingInterestRate();
	abstract void getFixedDepositInterestRate();
}
class ICICIBank extends GenralBank
{
	void getSavingInterestRate()
		{System.out.println("saving 4%");}
	void getFixedDepositInterestRate()
		{System.out.println("Fixed 8.5%");}
}
class SBIBank extends GenralBank
{
	void getSavingInterestRate()
		{System.out.println("saving 4%");}
	void getFixedDepositInterestRate()
		{System.out.println("Fixed 7%");}
}
class AbstractClass1
{
	public static void main(String[] args)
	{
		//ICICIBank i =new ICICIBank();
		//i.getFixedDepositInterestRate();

		//SBIBank s= new SBIBank();
		//s.getSavingInterestRate();
		
		//GenralBank g= new SBIBank();
		//g.getFixedDepositInterestRate();
		
		GenralBank g= new ICICIBank();
		g.getFixedDepositInterestRate();
	}
}