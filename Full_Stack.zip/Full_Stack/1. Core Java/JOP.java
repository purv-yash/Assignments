import javax.swing.*;

class JOP
{
	JFrame f;
	JOP()
	{
		//new JFrame();
		JOptionPane.showMessageDialog(f,"Hello, Welcome");
	}
	
	public static void main(String[] args)
	{
		JOP p = new JOP();
	}
}