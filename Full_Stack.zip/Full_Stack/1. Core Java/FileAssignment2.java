import java.io.*;

class FileAssignment2
{
	public static void main(String[] args) throws IOException
	{
		int total=0,a=0,e=0,i=0,o=0,u=0;
		
		FileInputStream f1 = new FileInputStream("d:/yash.txt");
		int r;
		while((r=f1.read())!= -1)
		{
			if((char)r=='a' || (char)r=='A')
			{
				++a; ++total;
			}
			if((char)r=='e' || (char)r=='E')
			{
				++e; ++total;
			}
			if((char)r=='i' || (char)r=='I')
			{
				++i; ++total;
			}
			if((char)r=='o' || (char)r=='O')
			{
				++o; ++total;
			}
			if((char)r=='u' || (char)r=='U')
			{
				++u; ++total;
			}
		}
		System.out.println("Total number of vowel is " +total);
		System.out.println("a is " + a + " times occur");
		System.out.println("e is " + e + " times occur");
		System.out.println("i is " + i + " times occur");
		System.out.println("o is " + o + " times occur");
		System.out.println("u is " + u + " times occur");
		
	}
}