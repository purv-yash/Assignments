class Array1
{
	public static void main(String[] args)
	{
			int[] a=new int[]{10,20,30,40,50,60};
			
			int sum=0, avg;
			for(int i:a)
			{
				sum= sum+i;
			}
			avg= sum/ a.length ;
	System.out.println("sum is:"+ sum);
	System.out.println("avg is:"+ avg);
	}
}