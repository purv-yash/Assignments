import java.util.*;
class Program11{
public static void main(String[] args){
 Scanner sc= new Scanner(System.in);
 System.out.println("a=");
 int a= sc.nextInt();
 int res=0;
	while(a>0)
	{
	res= res*10 + a%10;
	a = a/10;
	}
	
	System.out.println(res);
}
}