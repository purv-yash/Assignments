
public class DeggurDemo1 {

	public static void main(String[] args) {

		int i=90;
		
		if(i>100) {System.out.println("hii");}
		else System.out.println("hello");
	}

}
