class ExceptionDemo1
{
	public static void main (String[] args)
	{
		System.out.println("Purv Baraskar");
		System.out.println(100/0);
	}
}