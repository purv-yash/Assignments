class EnumWeek
{
	enum Weekdays{MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY;}
	
	public static void main(String[] args)
	{
		Weekdays w = Weekdays.valueOf("TUESDAY");
		switch(w)
		{
			case MONDAY: 	System.out.println("day 1"); break;
			case TUESDAY:	System.out.println("day 2"); break;
			case WEDNESDAY:	System.out.println("day 3"); break;
			case THURSDAY:	System.out.println("day 4"); break;
			case FRIDAY:	System.out.println("day 5"); break;
		}
		System.out.println("index of Friday is:"+ Weekdays.FRIDAY.ordinal());
	}
}