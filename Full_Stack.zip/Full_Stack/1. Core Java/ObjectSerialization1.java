import java.io.*;
import java.util.Scanner;
class Employee implements Serializable
{
	String name, department,designation;
	double salary;
	
	public String getName()
	{ return name; }
	public void setName(String name)
	{this.name=name;}
	
	public String getDepartment()
	{ return department; }
	public void setDepartment(String department)
	{this.department=department;}
	
	public String getDesignation()
	{ return designation; }
	public void setDesignation(String designation)
	{this.designation=designation;}
	
	public double getSalary()
	{ return salary; }
	public void setSalary(double salary) 
	{this.salary=salary;}
	
	public String toString()
	{
		return "[name=" + name + ",dapartment=" + department+ ", designation="+ designation + ",salary=" + salary + "]";
	}
	
	public static void main(String[] args) throws Exception
	{
		Scanner sc = new Scanner(System.in);
		Employee emp = new Employee();
		
		System.out.println("name:");
		emp.setName(sc.nextLine());
		System.out.println("department:");
		emp.setDepartment(sc.nextLine());
		System.out.println("designation:");
		emp.setDesignation(sc.nextLine());
		System.out.println("salary:");
		emp.setSalary(sc.nextDouble());
		sc.nextLine();
		
		FileOutputStream fos = new FileOutputStream("d:/yash.txt");
		ObjectOutputStream oos= new ObjectOutputStream(fos);
		oos.writeObject(emp);
		
		FileInputStream fis = new FileInputStream("d:/yash.txt");
		ObjectInputStream ois= new ObjectInputStream(fis);
		Employee emp2 = (Employee)ois.readObject();
		
		System.out.println("Name:" + emp2.getName());
		System.out.println("Department:" + emp2.getDepartment());
		System.out.println("Designation:" + emp2.getDesignation());
		System.out.println("Salary:" + emp2.getSalary());
		
		fos.close(); 	fis.close();	oos.close();	ois.close();
	}
}