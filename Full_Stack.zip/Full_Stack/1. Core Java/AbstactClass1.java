abstract class GenralBank
{
	abstract void getSavingInterestRate();
	abstract void getFixedDepositInterestRate();
}
class ICICIBank extends GenralBank
{
	void getSavingInterestRate("saving 4%");
	void getFixedDepositInterestRate("Fixed 8.5%");
}
class SBIBank extends GenralBank
{
	void getSavingInterestRate("Savin 4%");
	void getFixedDepositInterestRate("fixed 7%");
}
class AbstractClass1
{
	public static void main(String[] args)
	{
		
		
	}
}