import java.util.ArrayList;
import java.util.ListIterator;

public class ArrayList3 {

	public static void main(String[] args) {

		ArrayList<String> a = new ArrayList<String>();
		a.add("january");
		a.add("february");
		a.add("march");
		a.add("april");
		a.add("may");
		a.add("june");
		a.add("july");
		a.add("august");
		a.add("september");
		a.add("october");
		a.add("november");
		a.add("december");
		
		ListIterator i= a.listIterator();
		i.next();
		i.next();
		i.next();
		while(i.hasPrevious())
		{
			System.out.println(i.previous());
		}
		
	}

}
