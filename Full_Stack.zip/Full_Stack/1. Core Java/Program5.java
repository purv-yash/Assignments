import java.util.*;
class Program1{
public static void main(String[] args){
 Scanner sc= new Scanner(System.in);
 int a= sc.nextInt();
 int b= sc.nextInt();
 System.out.println("enter operator");
 char opr= scanner.next().charAt(0);
 
 switch(
}
}