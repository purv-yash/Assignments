class ThisDemo4
{
	void y1(ThisDemo4 t)
	{
			System.out.println("y1 method");
	}
	void y2()
	{
		y1(this);
	}
		
	public static void main(String[] args)
	{
			ThisDemo4 t= new ThisDemo4();
			t.y2();
	}
}