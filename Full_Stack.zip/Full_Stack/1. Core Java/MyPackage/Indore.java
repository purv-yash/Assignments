package MyPackage;

public class Indore
{
	public void city()
	{
		System.out.println("Indore is cleanest city");
	}
}