package com.automobile;
import com.automobile.twoWheeler.*;
public class Test
{
	public static void main(String[] args)
	{
		Honda h = new Honda();
		System.out.println(h.getSpeed());
	}
}