package com.automobile.twoWheeler;
import com.automobile.Vehicle;

public class Hero extends Vehicle
{
	public int getSpeed(){ return 90;}
	public void radio(){System.out.println("CD");}
	public String getModelName() { return "HONDA";}
	public String getRegistrationNumber() { return "1274";}
	public String getOwnerName() { return "RAM";}
}