import MyPackage.Indore;
class PackageDemo1
{
	public static void main(String[] args)
	{
		Indore ob = new Indore();
		ob.city();
	}
}