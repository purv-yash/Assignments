import java.util.Scanner;
class UncheckedException
{
	public static void main(String[] args)
	{
		
		String str= null;
		
		try
		{
			Scanner sc = new Scanner(System.in);
			String in = sc.nextLine();
			int n = Integer.parseInt(in);
			char[] c = new char[4];
			for(int i=0; i<4 ; i++)
			{
				c[i]=str.charAt(i);
			}
			System.out.println(c[6]);
		}
		catch(ArithmeticException e){ e.getMessage();}
		
		catch(NullPointerException e){ e.getMessage();}
		
		catch(ArrayIndexOutOfBoundsException e){ e.getMessage();}
		
		catch(StringIndexOutOfBoundsException e){ e.getMessage();}
		
		catch(NumberFormatException e){ e.getMessage();}
		
	}
}