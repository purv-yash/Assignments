class StringHW
{
	public static void main(String[] args)
	{
	String s1 = new String("Purv");
	String s2 = new String("Baraskar");
	int i=0;
	do
	{
			System.out.print(s1.charAt(i));
			System.out.print(s2.charAt(i));
			i++;
	}
	while(i<=s1.length()-1);
	
	
	}
}