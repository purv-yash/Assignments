import java.util.Map;
import java.util.HashMap;
import java.util.*;

class MapDemoT1
{
	public static void main(String[] args)
	{
	Map<Integer,String> m = new HashMap<Integer,String>();
	m.put(101,"Purv");
	m.put(105,"Aman");
	m.put(102,"Yash");
	m.put(99,"Purv");
	m.put(103,"Aman");
	m.put(97,"Yash");
	System.out.println(m);
	
	Map<Integer,String> n = new HashMap<Integer,String>();
	n.put(101,"Purv");
	n.put(105,"Aman");
	n.put(102,"Yash");
	System.out.println(n);
	for(Map.Entry map:m1.entrySet())
	{
		System.out.println(map.getKey() + map.getValue());
	}
	ArrayList<Interger> a= new ArrayList(m.keySet());
	Collections.sort(a);
	System.out.println(a);
	ArrayList<Interger> b= new ArrayList(m.values());
	Collections.sort(b);
	System.out.println(b);
	
	
	}
}