class t1
{
		t1(ThisDemo5 td)
		{
			System.out.println("t1 class constructor");
		}
}

class ThisDemo5
{
	void y1()
	{
			t1 t= new t1(this);ā
	}
	
	
	public static void main(String[] args)
	{
			ThisDemo5 t= new ThisDemo5();
			t.y1();
	}
}