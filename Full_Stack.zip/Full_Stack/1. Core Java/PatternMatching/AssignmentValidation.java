package PatternMatching;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class AssignmentValidation 
{
	static boolean isVMno(String s1)
	{
		Pattern p1 = Pattern.compile("[0-9]{10}");
		Matcher m1 = p1.matcher(s1);
		return (m1.find() && m1.group().equals(s1));
	}
	
	static boolean isEid(String s2)
	{
		Pattern p2 = Pattern.compile("^(.+)@(.+)$");
		Matcher m2 = p2.matcher(s2);
		return (m2.find() && m2.group().equals(s2));
	}

	static boolean isURL(String s3)
	{
		Pattern p3 = Pattern.compile("^(https?|ftp|file)://[a-zA-Z0-9+&@#/?=~_|!:,.;]*[a-zA-Z0-9+&@#/%=~_|]");
		Matcher m3 = p3.matcher(s3);
		return (m3.find() && m3.group().equals(s3));
	}

	public static void main(String[] args) 
	{
		String s1= "9027159325";
		if(isVMno(s1)) System.out.println("it is a valid mobile no.");
		else System.out.println("Invalid mobile no.");
		String s2= "purv22@gmail.com";
		if(isEid(s2)) System.out.println("it is a valid email id");
		else System.out.println("Invalid email id");
		String s3= "https://purv.com";
		if(isURL(s3)) System.out.println("it is a valid URL");
		else System.out.println("Invalid URL");
	}
}
