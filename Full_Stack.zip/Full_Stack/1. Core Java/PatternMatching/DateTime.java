package PatternMatching;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;

	public class DateTime {

	public static void currentDate()
	{

		LocalDate d = LocalDate.now();
		System.out.println("the current date is "+d);
		LocalTime t = LocalTime.now();
		System.out.println("the current time is "+t);	
		
		DateTimeFormatter f = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"); 
			   
			    String formatedDateTime = current.format(f); 
			    
			    System.out.println("in formatted manner "+
			                        formatedDateTime);
	}
	public static void main(String[] args)
	{
		currentDate();
	}
}


