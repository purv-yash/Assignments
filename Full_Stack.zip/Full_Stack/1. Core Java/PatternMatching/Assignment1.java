package PatternMatching;
public class Assignment1 
{
	static String extractNo(String s)
	{
		s= s.replaceAll("[^\\d]"," ");
		s= s.trim();
		s= s.replaceAll(" +", " ");
		if(s.equals(" ")) return "-1";
		return s;			
	}
	
	public static void main(String[] args) 
	{
		String s= "fahhhr3u9r@#$39y93yr2";
		System.out.println(extractNo(s));
	}
}
