package PatternMatching;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class Assignment4 
{
	 public static void main(String[] args)
	  {
	    String stringToSearch = "Institute of engineering and technology";

	    Pattern p = Pattern.compile(" (\\S+neer\\S+) ");   
	    Matcher m = p.matcher(stringToSearch);
 
	    if (m.find())
	    {
	      String theGroup = m.group(1);
	      System.out.format("'%s'\n", theGroup);
	    }

	  }
}
