class ThisDemo3
{
	ThisDemo3()
	{
		System.out.println("no argument constructor");
	}
	ThisDemo3(int a)
	{
		this();
		System.out.println("parametrised constructor");
	}
	
	public static void main(String[] args)
	{
			ThisDemo3 t= new ThisDemo3(5);
	}
}