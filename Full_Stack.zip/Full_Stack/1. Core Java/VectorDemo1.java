import java.util.Vector;

class VectorDemo1
{
	public static void main(String[] args)
	{
		Vector v= new Vector();
		v.add("Purv");
		v.add(2);
		v.add('b');
		System.out.println(v);
	}
}