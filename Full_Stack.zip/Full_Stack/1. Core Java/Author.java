class Author
{
	private String name, email;
	private char gender;
	
	Author(String name, String email, char gender)
	{
		this.name   = name;
		this.email  = email;
		this.gender = gender;
	}
	String getName(){return name;}
	String getEmail(){return email;}
	char getGender(){return gender;}
		
	public String toString()
	{
		return "(name= " + name + " gender= " + gender + " email= " + email + ")";
	}
}
class Book
{
	String name;
	double price;
	Author a;
	int qtyInStock;

		Book(String name, Author a, double price,int qtyInStock)
		{
			this.name= name;
			this.a= a;
			this.price= price;
			this.qtyInStock= qtyInStock;
		}
		
		double getPrice()
		{return price;}
		
		void setPrice(double price)
		{this.price= price;}

		double getQLY()
		{return qtyInStock;}
		
		void setQLY(int qtyInStock)
		{this.qtyInStock= qtyInStock;}
		
		String getName()
		{return name;}
		
		Author getAuthor()
		{return a;}
		
		public String toString()
		{
			return "(name of book= " + name + " author= " + a + " price= " + price +" qtyInStock= " + qtyInStock  + ")";
		}
}

class AuthorBookEncap
{
	public static void main(String[] args)
	{
		Author Purv = new Author("Purv","yash.com",'m');
		Book obj1 = new Book ("story",Purv, 200, 8);
		
		System.out.println(obj1);
	}
}