import java.io.FileInputStream;
import java.io.FileNotFoundException;

class ThrowD
{
	void show() throws FileNotFoundException
	{
		FileInputStream f= new FileInputStream("d:/yash.txt");
	}
}
class ThrowsDemo
{
	public static void main(String[] args)
	{
		ThrowD t= new ThrowD();
		try
		{
			t.show();
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		System.out.println("Hello, normal-Termination");
	}
}