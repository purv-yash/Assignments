import java.util.Iterator;
import java.util.Vector;

class employee {
	private int id;
	private String name;
	private Double salary;
	
	public employee(int id, String name, Double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}	

	public int getId() {
		return id;
	}
	
	public String toString() {
		return "employee [id=" + id + ", name=" + name +  ", salary=" + salary + "]";
	}
}

public class ListAssignment4 {

	public static void main(String[] args) {
		Vector<employee> list = new Vector<>();
		
		list.add(new employee(11, "Purv", 40000.0));
		list.add(new employee(12, "yash", 50000.0));
		list.add(new employee(13, "om", 2000.0));
		list.add(new employee(14, "raina", 10000.0));
		
		Iterator<employee> it = list.iterator();
		while (it.hasNext()) 
			System.out.println(it.next());
		

	}

}
