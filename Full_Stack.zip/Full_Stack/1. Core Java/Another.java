import testPackage.Foundation;

class Another
{
	public static void main(String[] args)
	{
	Foundation f = new Foundation();
	
	//f.var1= 10;
	//f.var2= 10;
	//f.var3= 10;
	f.var4= 10;
	
	}
}