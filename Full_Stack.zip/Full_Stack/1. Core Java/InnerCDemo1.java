class Outer
{
	static class Inner
	{
		void show()
		{
			System.out.println("Inner show");
		}
	}
}
class InnerCDemo1
{
	public static void main(String[] args)
	{
		Outer.Inner oi= new Outer.Inner();
		oi.show();
	}
}