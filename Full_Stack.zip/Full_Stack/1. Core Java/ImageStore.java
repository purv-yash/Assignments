import java.sql.*;
public class ImageStore {
public static void main(String[] args) {
	try {
		Class.forName("com.mysql.jdbc.Driver");
		String url="jdbc:mysql://localhost:3306/purv";
		String user="root";
		String pass="root";
		Connection con= DriverManager.getConnection(url,user,pass);
		PreparedStatement ps=con.prepareStatement("inset into image values(?,?)");
		
	}
}
}
