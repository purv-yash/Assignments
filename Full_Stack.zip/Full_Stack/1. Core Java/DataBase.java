package Project;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DataBase 
{
	public Connection start() throws ClassNotFoundException, SQLException {
	Class.forName("com.mysql.jdbc.Driver");
	String url="jdbc:mysql://localhost:3306/EmployeeManagement";
	String user="root";
	String pass="root";
	Connection con=DriverManager.getConnection(url,user,pass);
	return con;
	}

	public void close(Connection c) throws Exception
	{
	c.close();
	}
	
	public int insert1(Employee emp) throws Exception
	{
		int empNo = emp.getEmpNo();
		String name= emp.getName();
		String department= emp.getDept();
		double salary= emp.getSal();
		Connection con=start();
		
		PreparedStatement st=con.prepareStatement("insert into EmployeeData(empNo,name,department,salary) values(?,?,?,?)");
		st.setInt(1,empNo);
		st.setString(2,name);
		st.setString(3,department);
		st.setDouble(4,salary);
		int i= st.executeUpdate();
		close(con);
		if(i>0) {
		return 1;
		};
		return 0;
	}
	
	public void insert2() throws Exception
	{
		Connection con=start();
		PreparedStatement st=con.prepareStatement("select * from EmployeeData");
		ResultSet i= st.executeQuery();
		System.out.println("empNo\tname\tdepartment\tsalary");
		System.out.println();
		while(i.next())
		{
			int empNo= i.getInt("empNo");
			String name= i.getString("name");
			String dept= i.getString("department");
			int sal= i.getInt("salary");
			
			System.out.println(empNo+"\t"+ name +"\t"+ dept +"\t\t"+ sal);
		}
		close(con);
	}
	
	public int insert3(int empNo) throws Exception
	{
		int j=0;
		Connection con=start();
		PreparedStatement st=con.prepareStatement("select * from EmployeeData where empNo=?");
		st.setInt(1,empNo);
		ResultSet i= st.executeQuery();
		System.out.println("empNo\tname\tdepartment\tsalary");
		while(i.next())
		{
			j=1;
			int eNo= i.getInt("empNo");
			String name= i.getString("name");
			String dept= i.getString("department");
			int sal= i.getInt("salary");
			
			System.out.println(empNo+"\t"+ name +"\t"+ dept +"\t\t"+ sal);
		}
		close(con);
		if(j>0) {
			return 1;
			};
			return 0;
	}
	
	public int insert4(int empNo,int increment) throws Exception
	{
		
		Connection con=start();
		PreparedStatement st1=con.prepareStatement("select salary from EmployeeData where empNo=?");
		st1.setInt(1, empNo);
		ResultSet rs= st1.executeQuery();
		rs.next();
		double sal=rs.getDouble("salary");
		PreparedStatement st2=con.prepareStatement("update EmployeeData set salary=? where empNo=?");
		st2.setDouble(1,sal+increment);
		st2.setInt(2,empNo);
		int i= st2.executeUpdate();	
		close(con);
		if(i>0) {
			return 1;
			};
			return 0;
	}
	
	public int insert5(int empNo) throws Exception
	{
		Connection con=start();
		PreparedStatement st=con.prepareStatement("delete from EmployeeData where empNo=?");
		st.setInt(1, empNo);
		int i = st.executeUpdate();
		close(con);
		if(i>0) {
			return 1;
			};
			return 0;
	}
	
}
