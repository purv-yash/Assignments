package Thread;
public class ThreadyieldjJoin extends Thread{

	static Thread t;
	public void run()
	{
		try
		{
			t.join();
			for(int i=1;i<=3;i++)
			{
				System.out.println("run thread"+ i);
				Thread.sleep(500);
			}
		}
		catch(Exception e)
		{System.out.println(e);}
	}
	public static void main(String[] args)
	{
		t= Thread.currentThread();
		try
		{
//			t.join();
			for(int i=1;i<=3;i++)
			{
				System.out.println("main thread"+ i);
				Thread.sleep(500);
			}
		}
		catch(Exception e)
		{System.out.println(e);}
		ThreadyieldjJoin tyj= new ThreadyieldjJoin();
		tyj.start();
		
	}
}
