package Thread;

public class InterruptDemo {

}
