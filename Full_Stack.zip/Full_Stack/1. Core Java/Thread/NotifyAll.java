package Thread;
class RevenueA extends Thread
{
	public void run()
	{
		synchronized (this) {
		System.out.println("Thread-1");
		try {
			this.wait();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		}
	}
}
class RevenueB extends Thread
{	
	RevenueA r;
	RevenueB(RevenueA r){this.r=r;}
	public void run()
	{
		synchronized (this.r) {
		System.out.println("Thread-2");
		try 
		{
			this.r.wait();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		}
	}
}
class RevenueC extends Thread
{	
	RevenueA r;
	RevenueC(RevenueA r){this.r=r;}
	public void run()
	{
		synchronized (this.r) {
		System.out.println("Thread-3");
		try 
		{
			this.r.notifyAll();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		}
	}
}
public class NotifyAll
{
public static void main(String[] args) {
	
	RevenueA r1= new RevenueA();
	RevenueB r2= new RevenueB(r1);
	RevenueC r3= new RevenueC(r1);
	
	Thread t1= new Thread(r1);
	Thread t2= new Thread(r2);
	Thread t3= new Thread(r3);
	
	t1.start();
	t2.start();
	t3.start();
}
}
