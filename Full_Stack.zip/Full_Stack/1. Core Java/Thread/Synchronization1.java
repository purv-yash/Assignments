package Thread;

public class Synchronization1 {

}
