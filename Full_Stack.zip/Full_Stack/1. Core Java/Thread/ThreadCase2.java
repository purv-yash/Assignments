package Thread;

public class ThreadCase2 extends Thread {

	public void run()
	{
		Thread.currentThread().setName("Run");
		System.out.println("Run:"+ Thread.currentThread().getName());
	}
	public static void main(String[] args) {
		System.out.println(Thread.currentThread().getName());
		ThreadCase2 t1= new ThreadCase2();
		t1.setName("T1 head");
		t1.start();
		
		ThreadCase2 t2 = new ThreadCase2();
		t2.setName("T2 head");
		t2.start();
	}
}
