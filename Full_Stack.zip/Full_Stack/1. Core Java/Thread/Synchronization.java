package Thread;
class BookTicket
{
	int totalseats=12;
	//synchronized
	void bookSeat(int seats)
	{
		synchronized (this) {
		if(totalseats>=seats)
		{
			System.out.println("Booked Successfully");
			totalseats= totalseats-seats;
			System.out.println("Remaining seats"+ totalseats);
		}
		else
		{
			System.out.println("seats are not available"+ totalseats);
		}
	}
  }	
}

public class Synchronization extends Thread
{
	static BookTicket b;
	int seats;
	public void run()
	{
		b.bookSeat(seats);
	}
	public static void main(String[] args)
	{
		b= new BookTicket();
		Synchronization s1 = new Synchronization();
		s1.seats=5;
		s1.start();
		Synchronization s2 = new Synchronization();
		s2.seats=9;
		s2.start();
		
	}
	
}
