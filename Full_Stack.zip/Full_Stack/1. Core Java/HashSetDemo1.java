import java.util.HashSet;

class HashSetDemo1
{
	public static void main(String[] args)
	{
		HashSet hs= new HashSet();
		hs.add("Purv");
		hs.add(2);
		hs.add("Baraskar");
		System.out.println(hs);
	}
}