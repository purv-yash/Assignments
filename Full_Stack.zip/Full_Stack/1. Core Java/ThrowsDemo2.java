import java.io.*;

class ThrowsDemo2
{
	public static void main(String[] args) throws ClassNotFoundException
	{
		try
		{
		Class c = Class.forName("Purv");
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		System.out.println("Hello, normal-Termination");
	}
	
}