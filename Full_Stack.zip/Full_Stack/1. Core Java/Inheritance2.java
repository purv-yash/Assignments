class Person
{
	String name,dateOfBirth;
	Person(String name,String dateOfBirth)
	{
		this.name= name;
		this.dateOfBirth= dateOfBirth;
	}
}
class Teacher extends Person
{
	double salary;
	String subject;
	Teacher(String name, String dateOfBirth, String subject, double salary)
	{
		super(name,dateOfBirth);
		this.subject= subject;
		this.salary = salary;
	}
	void display()
	{
		System.out.println();
	}
}
class Student extends Person
{
	int studentId;
	Student(String name, String dateOfBirth, int studentId)
	{
		super(name,dateOfBirth);
		this.studentId= studentId;
	}
	void display()
	{
		System.out.println();
	}
}
class CollegeStudent extends Student
{
	String collegeName;
	String year;
	CollegeStudent(String name, String dateOfBirth, int studentId, String year, String collegeName)
	{
		super(name,dateOfBirth,studentId);
		this.collegeName=collegeName;
		this.year= year;
	}
	void display()
	{
		System.out.println("name= "+ name + "dob= " + dateOfBirth+ "studentId="+ studentId + "year= "+ year + "College name" +collegeName);
	}
}
class Inheritance2
{
	public static void main(String[] args)
	{
		Teacher t= new Teacher("Ram","01/07/1989","Java",50000);
		CollegeStudent cs= new CollegeStudent("Purv","22/08/2001",141,"2022","IET");
		cs.display();
	}
}