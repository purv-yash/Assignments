class String1
{
	public static void main(String[] args)
	{
		String s = new String("Purv");
		String s1 = new String("");
	
		
		System.out.println(s.isEmpty());
		System.out.println(s1.isEmpty());
	}
}