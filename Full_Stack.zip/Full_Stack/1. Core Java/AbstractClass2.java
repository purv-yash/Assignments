abstract class Compartment
{
	public abstract String notice();
}

class FirstClass extends Compartment
{
	String notice()
	{
		System.out.println("This is First Class");
		return null;
	}
}

class Ladies extends Compartment
{
	String notice()
	{
		System.out.println("This is Ladies Compartment");
		return null;
	}
}
class General extends Compartment
{
	String notice()
	{
		System.out.println("This is Genral Class");
		return null;
	}
}
class Luggage extends Compartment
{
	String notice()
	{
		System.out.println("This is Luggage Compartment");
		return null;
	}
}

class TestCompartment
{
	public static void main(String[] args)
	{
		int min= 1, max= 4;
		int c[]= new int [10];
		
		FirstClass f = new FirstClass();
		Ladies l = new Ladies();
		General g= new General();
		Luggage x= new Luggage();
		
		for(int i=0; i<10;i++)
		{
			int b = (int)(Math.random()*(max-min+1)+min);
			c[i]=b;
		}
		for(int i=0; i<10; i++)
		{
			if(c[i]==1) f.notice();
			if(c[i]==2) l.notice();
			if(c[i]==3) g.notice();
			if(c[i]==4) x.notice();
		}
	}
}