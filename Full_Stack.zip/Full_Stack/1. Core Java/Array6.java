class Array6
{
	public static void main(String[] args)
	{
			int[] a=new int[]{10,20,50,8,30,40};
			int[] b=new int[];
			int x=0;
				  
			for(int i=0;i<a.length;i++)
			{
				for(int j=0;j<a.length;j++)
				{
				if(i==j)
				{ 
					b[x]= a[j];
					x++;
				if(i!=j)
				{					
					if(a[i]==a[j])
					{
						
					}
				}
			}	
			for(int x:a)
			{
				System.out.println(x);
			}	
	}
}