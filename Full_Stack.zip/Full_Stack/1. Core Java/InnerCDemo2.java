class Outer
{
	class Inner
	{
		void show()
		{
			System.out.println("Inner show");
		}
	}
}
class InnerCDemo2
{
	public static void main(String[] args)
	{
		Outer o = new Outer();
		Outer.Inner oi= o.new Inner();
		oi.show();
	}
}