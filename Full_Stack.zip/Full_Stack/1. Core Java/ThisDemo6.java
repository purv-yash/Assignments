class ThisDemo6
{
	int x;
	ThisDemo6(int y)
	{
		x= 2*y;
		return this;
	}
	
	
	public static void main(String[] args)
	{
			int twos;
			ThisDemo6 t= new ThisDemo6(5);
			
			System.out.println(twos);
			
	}
}