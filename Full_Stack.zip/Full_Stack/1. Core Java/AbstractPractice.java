abstract class College
{
	abstract void location();
}
class IET extends College
{
	void location()
	{
		System.out.println("IET located near IT Park");
	}
}	
class SGSITS extends College
{
	void location()
	{
		System.out.println("SGSITS located near Railway Station");
	}
}	
class AbstractPractice
{
	public static void main(String[] args)
	{
		IET obj1 = new IET();
		SGSITS obj2= new SGSITS();
		
		obj1.location();
		obj2.location();
	}
}