package Project;
import java.util.ArrayList;
public class Company
{
		DataBase db = new DataBase();
		
		public void addEmployee(Employee emp) throws Exception
		{
			int j= db.insert1(emp);
			if(j==1)System.out.println("Employee added successfully");
			else System.out.println("can't add");
		}
		
		public void getEmployee() throws Exception
		{
			db.insert2();
		}
		
		public void getEmployee(int empNo) throws Exception
		{
			int j=db.insert3(empNo);
			if(j==0)System.out.println("Employee not found.");
		}
		
		public void updateSal(int empNo,int increment) throws Exception
		{
			int j=db.insert4(empNo, increment);
			if(j==0)System.out.println("Employee not found.");
			else System.out.println("Salary updated successfully");
		}
		
		public void removeEmployee(int empNo) throws Exception
		{
			int j=db.insert5(empNo);
			if(j==0)System.out.println("Employee not found.");
			else System.out.println("Employee removed successfully");
		}
}
//ArrayList<Employee> empList=new ArrayList<Employee>();
//empList.add(emp);
//for(Employee e:empList){System.out.println(e.getName()+" " + e.getEmpNo() +" " + e.getDept());}
//for(Employee e:empList){
//if(e.getEmpNo()== empNo){
//System.out.println(e.getName() + " " +e.getEmpNo() +" " + e.getDept());
//b= false;}}
//for(Employee e:empList){
//if(e.getEmpNo()== empNo){
//double temp=e.getSal();
//e.setSal(temp + increment);
//System.out.println("new salary is:"+ e.getSal());
//b= false;
//}}
//for(Employee e:empList){
//if(e.getEmpNo()== empNo){
//empList.remove(e);
//System.out.println("Employee removed successfully.");
//b= false;}}