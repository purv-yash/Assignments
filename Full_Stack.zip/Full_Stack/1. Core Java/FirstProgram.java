class FirstProgram{
public static void main(String[] arg)
{
	System.out.println("yash technology is my first company");
}
}