class A
{
	void displayA()
	{
		System.out.println("A class");
	}
}
class B extends A
{
	void displayB()
	{
		System.out.println("B class");
	}
}
class C extends A
{
	void displayC()
	{
		System.out.println("C class");
	}
	public static void main(String[] args)
	{
		A obj1 = new A();
		obj1.displayA();
		B obj2 = new B();
		obj2.displayA();
		obj2.displayB();
		C obj3 = new C();
		obj3.displayA();
		obj3.displayC();
	}
}