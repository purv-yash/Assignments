package com.yash.springAOP.services;

public interface PaymentService {

	public void makePayment();
}
