package springmvc.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.tomcat.jni.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class DemoController {

//	@RequestMapping("/home")
//	public String home(Model Model) {
//		Model.addAttribute("name", "jay");
//		List<String> names= new ArrayList<>();
//		names.add("Purv");
//		names.add("Vijay");
//		Model.addAttribute("names", names);
//		return "index";
//	}
//
//	@RequestMapping(path="/request",method=RequestMethod.POST)
//	public String handlerequest(@RequestParam("email") String emailid)
//	{
//	System.out.println(emailid);
//	return "";
//	}
	
	@GetMapping("/")
	public String index(Model model) {
	model.addAttribute("user", new User());
	return "index";
	}



	@PostMapping("save")
	public String save(@ModelAttribute("user") User user, Model model) {
	model.addAttribute("user", user);
	return "response";
	}
}
